function init(){
   
    var xValues = ["Học Kỳ I", "Học Kỳ II", "Học Kỳ III"];
var yValues = [7.5, 6.9,5.5];
var barColors = ["red", "green","blue"];

new Chart("myChart", {
  type: "bar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "Bảng Điểm Từng Học Kỳ"
    }
  }
  
});
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
var data = google.visualization.arrayToDataTable([
  ['Contry', 'Mhl'],
  ['ĐẠT',95],
  ['RỚT',5],
]);

var options = {
  title:'Tỷ Lệ Qua Môn'
};

var chart = new google.visualization.PieChart(document.getElementById('myChart1'));
  chart.draw(data, options);
}
  document.getElementById("chart").style.display = 'block';
    document.getElementById("mark").style.display = 'none';
    document.getElementById("info").style.display = 'none';
    document.getElementById("infoteacher").style.display = 'none';
    document.getElementById("user").style.display = 'none';

    document.getElementById("admin").onclick=function(){
      document.getElementById("chart").style.display = 'block';
    document.getElementById("mark").style.display = 'none';
    document.getElementById("info").style.display = 'none';
    document.getElementById("infoteacher").style.display = 'none';
    document.getElementById("user").style.display = 'none';
}
    document.getElementById("bangdiem").onclick = function () {
    document.getElementById("mark").style.display = 'block';
    document.getElementById("HK1").style.display = 'block';
      document.getElementById("HK2").style.display = 'none';
    document.getElementById("HK3").style.display = 'none';
    document.getElementById("HKI").onclick = function (){
      document.getElementById("HK1").style.display = 'block';
      document.getElementById("HK2").style.display = 'none';
    document.getElementById("HK3").style.display = 'none';
     }
     document.getElementById("HKII").onclick = function (){
      document.getElementById("HK1").style.display = 'none';
      document.getElementById("HK2").style.display = 'block';
    document.getElementById("HK3").style.display = 'none';
     }
     document.getElementById("HKIII").onclick = function (){
      document.getElementById("HK1").style.display = 'none';
      document.getElementById("HK2").style.display = 'none';
    document.getElementById("HK3").style.display = 'block';
     }
    document.getElementById("info").style.display = 'none';
    document.getElementById("infoteacher").style.display = 'none';
    document.getElementById("user").style.display = 'none';
    document.getElementById("chart").style.display = 'none';
};
document.getElementById("pass").onclick = function () {
    document.getElementById("mark").style.display = 'none';
    document.getElementById("info").style.display = 'none';
    document.getElementById("infoteacher").style.display = 'none';
    document.getElementById("user").style.display = 'block';
    document.getElementById("chart").style.display = 'none';
};
document.getElementById("thongtinhhs").onclick = function () {
    document.getElementById("mark").style.display = 'none';
    document.getElementById("info").style.display = 'block';
    document.getElementById("infoteacher").style.display = 'none';
    document.getElementById("user").style.display = 'none';
    document.getElementById("chart").style.display = 'none';
};
document.getElementById("giaovien").onclick = function () {
    document.getElementById("mark").style.display = 'none';
    document.getElementById("info").style.display = 'none';
    document.getElementById("infoteacher").style.display = 'block';
    document.getElementById("GVHKI").style.display='block'
    document.getElementById("GVHKII").style.display='none'
    document.getElementById("GVHKIII").style.display='none'
    document.getElementById("GVHK1").onclick = function (){
      document.getElementById("GVHKI").style.display='block'
    document.getElementById("GVHKII").style.display='none'
    document.getElementById("GVHKIII").style.display='none'
    }
    document.getElementById("GVHK2").onclick = function (){
      document.getElementById("GVHKII").style.display='block'
    document.getElementById("GVHKI").style.display='none'
    document.getElementById("GVHKIII").style.display='none'
    }
    document.getElementById("GVHK3").onclick = function (){
      document.getElementById("GVHKIII").style.display='block'
    document.getElementById("GVHKII").style.display='none'
    document.getElementById("GVHKI").style.display='none'
    }
    document.getElementById("user").style.display = 'none';
    document.getElementById("chart").style.display = 'none';
};
}
function changepass(){
  if(confirm("Bạn Muốn Lưu Chứ"))
     {
      document.getElementById("text").value="";
      document.getElementById("password").value="";
      document.getElementById("password1").value="";
     } 
    }
     function deletepass(){
          document.getElementById("text").value="";
          document.getElementById("password").value="";
          document.getElementById("password1").value="";
        } 