const ListAccount = [
    {
        username:"admin",
        password:"admin"
    },
]
const ListAccount1 = [
    {
        username:"tu",
        password:"123456"
    },
]
let isLogin = !!localStorage.getItem("token")
let isLogin1 = !!localStorage.getItem("token1")
function Login(){
    
    let username = document.getElementById("username").value
    let password = document.getElementById("password").value
    let dangnhap=document.getElementById("select").value
    console.log(dangnhap)
    if(dangnhap==="gv"){
    let checkLogin = ListAccount.some(value => value.username === username && value.password === password)
    if (checkLogin) {
        localStorage.setItem("token", username) 
        isLogin = true
        CheckLogin()
       
    }
    else{
        alert("Không tìm thấy thông tin! \nVui lòng kiểm tra lại.")
    }
}
if(dangnhap==="sv"){
    let checkLogin1 = ListAccount1.some(value => value.username === username && value.password === password)
    /* console.log(checkLogin) */
    if(checkLogin1)
    {
        localStorage.setItem("token1", username) 
        isLogin = true
        CheckLogin2()
       
    } else{
        alert("Không tìm thấy thông tin! \nVui lòng kiểm tra lại.")
    }
}
}
function CheckLogin(){
    if (isLogin) {
        window.location.href = "HeThongNhapDiemGiaoVien.html"
    }
}

function CheckLogin1(){
    localStorage.setItem("token","")
    if (isLogin) {
        window.location.href = "HeThongNhapDiemGiaoVien.html"
    }
   
}
function CheckLogin2(){
    if (isLogin1) {
        window.location.href = "Hethongnhapdiem.html"
    }
   
}
function CheckLogin3(){
    localStorage.setItem("token1","")
    if (isLogin1) {
        window.location.href = "Hethongnhapdiem.html"
    }
   
}