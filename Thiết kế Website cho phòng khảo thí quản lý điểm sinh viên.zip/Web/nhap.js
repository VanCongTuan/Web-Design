let teacher=[]
let t=[]
function clearteacher()
{
 document.getElementById("NAME").value=""; 
 document.getElementById("M").value=""; 
 document.getElementById("addstress").value="";
  document.getElementById("phone").value="";
   document.getElementById("TD").value="";
    document.getElementById("K").value=""; 
    document.getElementById("Username").value="";
     document.getElementById("Password").value="";
     }
 function addteacher(){
    
        let item_NAME=document.getElementById("NAME").value
        let item_GIOTINH=document.getElementById("M").value
        let item_addstress=document.getElementById("addstress").value
        let item_phone=document.getElementById("phone").value
        let item_trinhdo=document.getElementById("TD").value
        let item_khoa=document.getElementById("K").value
        let item_Username=document.getElementById("Username").value
        let item_Password=document.getElementById("Password").value
     let listteacher=localStorage.getItem("list-teacher") ? JSON.parse(localStorage.getItem("list-teacher")):[];
     listteacher.push({
        NAME:item_NAME,
        GIOTINH:item_GIOTINH,
        addstress:item_addstress,
        phone:item_phone,
        trinhdo :item_trinhdo,
        khoa:item_khoa,
        Username:item_Username,
        Password:item_Password
     })
     localStorage.setItem("list-teacher",JSON.stringify( listteacher))
     readerteacher();
     clearteacher();
   
 }
 
 function readerteacher(){
 
    let listteacher=localStorage.getItem("list-teacher") ? JSON.parse(localStorage.getItem("list-teacher")):[];
     let table=`
     <tr class="phongchu3 phongchu9">
     <td>ID</td>
     <td>Họ Tên</td>
     <td>Giới tính</td>
     <td>Địa chỉ</td>
     <td>Số Điện Thoại</td>
     <td>Trình độ</td>
     <td>Khoa</td>
     <td>Username</td>
     <td>Password</td>
     <td>ThaoTác</td>
 </tr>`    
 listteacher.map((value,index)=>{
        table +=`
        <tr class=" phongchu9">
                <td>${index+1}</td>
                <td>${value.NAME}</td>
                <td>${value.GIOTINH}</td>
                <td>${value.addstress}</td>
                <td>${value.phone}</td>
                <td>${value.trinhdo}</td>
                <td>${value.khoa}</td>
                <td>${value.Username}</td>
                <td>${value.Password}</td>
                <td><button onclick="deleteitemteacher(${index})" >
                <i class="fa-solid fa-box"></i></button>
                <button onclick="editteacher(${index})" >
                <i class="fa-solid fa-pen-to-square"></i></td>

            </tr>`
 })
 document.getElementById("table1").innerHTML=table
 }
 function editteacher(index){
     let listteacher=localStorage.getItem("list-teacher") ? JSON.parse(localStorage.getItem("list-teacher")):[]; 
     document.getElementById("NAME").value=listteacher[index].NAME; 
     document.getElementById("M").value=listteacher[index].GIOTINH; 
     document.getElementById("addstress").value=listteacher[index].addstress;
    document.getElementById("phone").value=listteacher[index].phone;
    document.getElementById("TD").value=listteacher[index].trinhdo;
    document.getElementById("K").value=listteacher[index].khoa; 
    document.getElementById("Username").value=listteacher[index].Username;
    document.getElementById("Password").value=listteacher[index].Password;
    
    document.getElementById("indexteacher").value=index
     document.getElementById("add1").style.display="none"
     document.getElementById("save1").style.display="inline-block"
 }
 function changeTeacher(){
    let listteacher=localStorage.getItem("list-teacher") ? JSON.parse(localStorage.getItem("list-teacher")):[]; 
     let index=document.getElementById("indexteacher").value
     listteacher[index]={
        NAME: document.getElementById("NAME").value,
        GIOTINH: document.getElementById("M").value,
        addstress: document.getElementById("addstress").value,
        phone: document.getElementById("phone").value,
        trinhdo : document.getElementById("TD").value,
        khoa:document.getElementById("K").value,
        Username: document.getElementById("Username").value,
        Password:document.getElementById("Password").value
     }
     localStorage.setItem("list-teacher",JSON.stringify(listteacher))
     readerteacher()
     document.getElementById("add1").style.display="inline-block"
     document.getElementById("save1").style.display="none"
    clearteacher();
 }
 function deleteitemteacher(index){
     let listteacher=localStorage.getItem("list-teacher") ? JSON.parse(localStorage.getItem("list-teacher")):[];
     if(confirm("Bạn muốn xóa chứ"))
     {
         listteacher.splice(index,1)
 
     } 
     localStorage.setItem("list-teacher",JSON.stringify(listteacher))
     readerteacher()
 }
function readerteacher1(listteacher){
    let table=`
    <tr class="phongchu3 phongchu9">
    <td>ID</td>
    <td>Họ Tên</td>
    <td>Giới tính</td>
    <td>Địa chỉ</td>
    <td>Số Điện Thoại</td>
    <td>Trình độ</td>
    <td>Khoa</td>
    <td>Username</td>
    <td>Password</td>
    <td>ThaoTác</td>
</tr>`    
listteacher.map((value,index)=>{
   
       table +=`
       <tr class=" phongchu9">
               <td>${index+1}</td>
               <td>${value.NAME}</td>
               <td>${value.GIOTINH}</td>
               <td>${value.addstress}</td>
               <td>${value.phone}</td>
               <td>${value.trinhdo}</td>
               <td>${value.khoa}</td>
               <td>${value.Username}</td>
               <td>${value.Password}</td>
               <td><button onclick="deleteitemteacher(${index})" >
               <i class="fa-solid fa-box"></i></button>
               <button onclick="editteacher(${index})" >
               <i class="fa-solid fa-pen-to-square"></i></td>

           </tr>`
})
document.getElementById("table1").innerHTML=table
}

 
 function searchteacher(){
    let listteacher=localStorage.getItem("list-teacher") ? JSON.parse(localStorage.getItem("list-teacher")):[];
let valuesearch=document.getElementById("searchteacher").value
let teachersearch=listteacher.filter(value=>{
    return value.NAME.toUpperCase().includes(valuesearch.toUpperCase())
})
readerteacher1(teachersearch)
document.getElementById("searchteacher").value=""
}

function ascendingteacher(){
    let listteacher=localStorage.getItem("list-teacher") ? JSON.parse(localStorage.getItem("list-teacher")):[];
    let valueSelect=document.getElementById("sortteacher").value
    listteacher.sort((a , b)=>{
        if(valueSelect==="az"){
            return a.NAME.localeCompare(b.NAME)
        }else if(valueSelect==="za"){
            return b.NAME.localeCompare(a.NAME)
        }else {
            return a.NAME-b.NAME
        }
    })
    readerteacher1(listteacher)
    
}















 function clearkhoa()
{ 
 document.getElementById("MAKHOA").value=""; 
 document.getElementById("NAMEKHOA").value=""; 
     }
 function addkhoa(){
     let khoa=[]
    let item_MAKHOA=document.getElementById("MAKHOA").value
    let item_NAMEKHOA=document.getElementById("NAMEKHOA").value
    let listkhoa=localStorage.getItem("list-khoa") ? JSON.parse(localStorage.getItem("list-khoa")):[];
    listkhoa.push({
        MAKHOA:item_MAKHOA,
        NAMEKHOA:item_NAMEKHOA
    })
    localStorage.setItem("list-khoa",JSON.stringify( listkhoa))
    readerkhoa();
    clearkhoa();
}
function readerkhoa(){
    let listkhoa=localStorage.getItem("list-khoa") ? JSON.parse(localStorage.getItem("list-khoa")):[];
        table1=`
        <tr class="phongchu3 phongchu9">
        <td>ID</td>
        <td>Mã Khoa</td>
        <td>Tên Khoa</td>
        <td>Thao Tác</td>
    </tr>`      
    listkhoa.map((value,index)=>{
                table1 +=`
                <tr class=" phongchu9">
                        <td>${index+1}</td>
                        <td>${value.MAKHOA}</td>
                        <td>${value.NAMEKHOA}</td>
                        <td><button onclick="deletekhoa(${index})" >
                        <i class="fa-solid fa-box"></i></button>
                        <button onclick="editkhoa(${index})" >
                        <i class="fa-solid fa-pen-to-square"></i></td>

                    </tr>
                `
        })
        document.getElementById("table2").innerHTML=table1
    
}
function changekhoa(){
    let listkhoa=localStorage.getItem("list-khoa") ? JSON.parse(localStorage.getItem("list-khoa")):[];
     let index=document.getElementById("indexkhoa").value
     listkhoa[index]={
        MAKHOA:  document.getElementById("MAKHOA").value,
        NAMEKHOA: document.getElementById("NAMEKHOA").value
     }
     localStorage.setItem("list-khoa",JSON.stringify( listkhoa))
     readerkhoa()
     document.getElementById("add2").style.display="inline-block"
     document.getElementById("save2").style.display="none"
    clearkhoa();
 }
function deletekhoa(index){
    let listkhoa=localStorage.getItem("list-khoa") ? JSON.parse(localStorage.getItem("list-khoa")):[];
    if(confirm("Bạn muốn xóa chứ"))
    {
        listkhoa.splice(index,1)

    } 
    localStorage.setItem("list-khoa",JSON.stringify( listkhoa))
    readerkhoa()
}
    function editkhoa(index){
        let listkhoa=localStorage.getItem("list-khoa") ? JSON.parse(localStorage.getItem("list-khoa")):[];
                document.getElementById("MAKHOA").value=listkhoa[index].MAKHOA; 
                document.getElementById("NAMEKHOA").value=listkhoa[index].NAMEKHOA; 
                document.getElementById("indexkhoa").value=index
                document.getElementById("add2").style.display="none"
                document.getElementById("save2").style.display="inline-block"
            }
            function searchkhoa(){
                let listkhoa=localStorage.getItem("list-khoa") ? JSON.parse(localStorage.getItem("list-khoa")):[];
            let valuesearch=document.getElementById("searchkhoa").value
            let khoasearch=listkhoa.filter(value=>{
                return value.MAKHOA.toUpperCase().includes(valuesearch.toUpperCase())
            })
            readerkhoa1(khoasearch)
            document.getElementById("searchkhoa").value=""
            }
            function readerkhoa1(listkhoa){
                    table1=`
                    <tr class="phongchu3 phongchu9">
                    <td>ID</td>
                    <td>Mã Khoa</td>
                    <td>Tên Khoa</td>
                    <td>Thao Tác</td>
                </tr>`      
                listkhoa.map((value,index)=>{
                            table1 +=`
                            <tr class=" phongchu9">
                                    <td>${index+1}</td>
                                    <td>${value.MAKHOA}</td>
                                    <td>${value.NAMEKHOA}</td>
                                    <td><button onclick="deletekhoa(${index})" >
                                    <i class="fa-solid fa-box"></i></button>
                                    <button onclick="editkhoa(${index})" >
                                    <i class="fa-solid fa-pen-to-square"></i></td>
            
                                </tr>
                            `
                    })
                    document.getElementById("table2").innerHTML=table1
                
            }

function clearmon()
            { 
             document.getElementById("MAMONHOC").value=""; 
             document.getElementById("NAMEMONHOC").value=""; 
                 }
             function addmon(){
                let Mon=[]
                let item_MAMONHOC=document.getElementById("MAMONHOC").value
                let item_NAMEMONHOC=document.getElementById("NAMEMONHOC").value
                let listmon=localStorage.getItem("list-mon") ? JSON.parse(localStorage.getItem("list-mon")):[];
                listmon.push({
                    MAMONHOC:item_MAMONHOC,
                    NAMEMONHOC:item_NAMEMONHOC
                })
                localStorage.setItem("list-mon",JSON.stringify( listmon))
                readermon();
                clearmon();
            }
            function readermon(){
                let listmon=localStorage.getItem("list-mon") ? JSON.parse(localStorage.getItem("list-mon")):[];
                    table2=`
                    <tr class="phongchu3 phongchu9">
                    <td>ID</td>
                    <td>Mã Môn Học </td>
                    <td>Tên Môn Học</td>
                    <td>Thao Tác</td>
                </tr>`      
                listmon.map((value,index)=>{
                            table2 +=`
                            <tr class=" phongchu9">
                                    <td>${index+1}</td>
                                    <td>${value.MAMONHOC}</td>
                                    <td>${ value.NAMEMONHOC}</td>
                                    <td><button onclick="deletemon(${index})" >
                                    <i class="fa-solid fa-box"></i></button>
                                    <button onclick="editmon(${index})" >
                                    <i class="fa-solid fa-pen-to-square"></i></td>
                                </tr>
                            `
                    })
                    document.getElementById("table3").innerHTML=table2
                
            }
            
                 function deletemon(index){
                    let listmon=localStorage.getItem("list-mon") ? JSON.parse(localStorage.getItem("list-mon")):[];
                    if(confirm("Bạn muốn xóa chứ"))
                    {
                        listmon.splice(index,1)
                
                    } 
                    localStorage.setItem("list-mon",JSON.stringify( listmon))
                    readermon()
                }
                function editmon(index){
                    let listmon=localStorage.getItem("list-mon") ? JSON.parse(localStorage.getItem("list-mon")):[];
                            document.getElementById("MAMONHOC").value= listmon[index].MAMONHOC; 
                            document.getElementById("NAMEMONHOC").value=listmon[index].NAMEMONHOC; 
                            document.getElementById("indexmon").value=index
                            document.getElementById("add3").style.display="none"
                            document.getElementById("save3").style.display="inline-block"
                        }
                function changemon(){
                    let listmon=localStorage.getItem("list-mon") ? JSON.parse(localStorage.getItem("list-mon")):[];
                             let index=document.getElementById("indexmon").value
                             listmon[index]={
                                MAMONHOC:document.getElementById("MAMONHOC").value,
                                NAMEMONHOC:  document.getElementById("NAMEMONHOC").value
                             }
                             localStorage.setItem("indexmon",JSON.stringify(listmon))
                             readermon()
                             document.getElementById("add3").style.display="inline-block"
                             document.getElementById("save3").style.display="none"
                            clearmon();
                         }
                         function searchmon(){
                            let listmon=localStorage.getItem("list-mon") ? JSON.parse(localStorage.getItem("list-mon")):[];
                        let valuesearch=document.getElementById("searchmon").value
                        let monsearch=listmon.filter(value=>{
                            return value.MAMONHOC.toUpperCase().includes(valuesearch.toUpperCase())
                        })
                        readermon1(monsearch)
                        document.getElementById("searchmon").value=""
                        }
                        function readermon1(listmon){

                                table2=`
                                <tr class="phongchu3 phongchu9">
                                <td>ID</td>
                                <td>Mã Môn Học </td>
                                <td>Tên Môn Học</td>
                                <td>Thao Tác</td>
                            </tr>`      
                            listmon.map((value,index)=>{
                                        table2 +=`
                                        <tr class=" phongchu9">
                                                <td>${index+1}</td>
                                                <td>${value.MAMONHOC}</td>
                                                <td>${ value.NAMEMONHOC}</td>
                                                <td><button onclick="deletemon(${index})" >
                                                <i class="fa-solid fa-box"></i></button>
                                                <button onclick="editmon(${index})" >
                                                <i class="fa-solid fa-pen-to-square"></i></td>
                                            </tr>
                                        `
                                })
                                document.getElementById("table3").innerHTML=table2
                            
                        }


function clearclass(){
   document.getElementById("codeclass").value=""
    document.getElementById("nameclass").value=""
 }
function addNew(){

    let classElement=document.querySelector(".classroom")
    let errorElement=classElement.querySelectorAll(".class-input")
    let dslop=[]
       
        let codeclass=document.getElementById("codeclass").value
        let nameclass=document.getElementById("nameclass").value
    let listclass=localStorage.getItem("list-class") ? JSON.parse(localStorage.getItem("list-class")):[];
    listclass.push({
      
        codeclass:codeclass,
        nameclass:nameclass
    })
    localStorage.setItem("list-class",JSON.stringify(listclass))
    readerclass();
    clearclass();
  
}
function readerclass(){
    let listclass=localStorage.getItem("list-class") ? JSON.parse(localStorage.getItem("list-class")):[];
    let classroom=`
    <tr class="phongchu3 phongchu9">
    <td>ID</td>
    <td>Mã lớp </td>
    <td>Tên lớp</td>
    <td>Thao Tác</td>
</tr>`
listclass.map((value,index)=>{
    classroom += `<tr class=" phongchu9">
    <td>${index+1}</td>
    <td>${value.codeclass}</td>
    <td>${value.nameclass}</td>
    <td><button onclick="deleteitemclass(${index})">
    <i class="fa-solid fa-box"></i></button>
    <button onclick="editClass(${index})">
    <i class="fa-solid fa-pen-to-square"></i></td>
   </tr> `
})
document.getElementById("table4").innerHTML=classroom
}
function editClass(index){
    let listclass=localStorage.getItem("list-class") ? JSON.parse(localStorage.getItem("list-class")):[]; 
    document.getElementById("codeclass").value=listclass[index].codeclass
    document.getElementById("nameclass").value=listclass[index].nameclass
    document.getElementById("indexclass").value=index


    document.getElementById("add").style.display="none"
    document.getElementById("save").style.display="inline-block"
}
function changeClass(){
    let listclass=localStorage.getItem("list-class") ? JSON.parse(localStorage.getItem("list-class")):[]; 
    let index=document.getElementById("indexclass").value
    listclass[index]={
        codeclass:document.getElementById("codeclass").value,
        nameclass:document.getElementById("nameclass").value
    }
    localStorage.setItem("list-class",JSON.stringify(listclass))
    readerclass()
    document.getElementById("add").style.display="inline-block"
    document.getElementById("save").style.display="none"
   clearclass();
}
function deleteitemclass(index){
    let listclass=localStorage.getItem("list-class") ? JSON.parse(localStorage.getItem("list-class")):[];
    if(confirm("Bạn muốn xóa chứ"))
    {
        listclass.splice(index,1)

    } 
    localStorage.setItem("list-class",JSON.stringify(listclass))
    readerclass()
}
function searchclass(){
    let listclass=localStorage.getItem("list-class") ? JSON.parse(localStorage.getItem("list-class")):[];
let valuesearch=document.getElementById("searchclass").value
let classsearch=listclass.filter(value=>{
    return value.codeclass.toUpperCase().includes(valuesearch.toUpperCase())
})
readerclass1(classsearch)
document.getElementById("searchclass").value=""
}
function readerclass1(classsearch){
    let classroom=`
    <tr class="phongchu3 phongchu9">
    <td>ID</td>
    <td>Mã lớp </td>
    <td>Tên lớp</td>
    <td>Thao Tác</td>
</tr>`
classsearch.map((value,index)=>{
    classroom += `<tr class=" phongchu9">
    <td>${index+1}</td>
    <td>${value.codeclass}</td>
    <td>${value.nameclass}</td>
    <td><button onclick="deleteitemclass(${index})">
    <i class="fa-solid fa-box"></i></button>
    <button onclick="editClass(${index})">
    <i class="fa-solid fa-pen-to-square"></i></td>
   </tr> `
})
document.getElementById("table4").innerHTML=classroom
}

function clearstudent()
{ 
 document.getElementById("mssv").value=""; 
 document.getElementById("namestudent").value=""; 
 document.getElementById("gender").value=""; 
 document.getElementById("birthday").value=""; 
 document.getElementById("classstudent").value=""; 
 document.getElementById("khoastudent").value="";      
}
 function addstudent(){
   let item_mssv= document.getElementById("mssv").value; 
   let item_namestudent=document.getElementById("namestudent").value; 
   let item_gender=document.getElementById("gender").value; 
   let item_birthday=document.getElementById("birthday").value; 
   let item_classstudent=document.getElementById("classstudent").value; 
   let item_khoastudent=document.getElementById("khoastudent").value; 
    let liststudent=localStorage.getItem("list-student") ? JSON.parse(localStorage.getItem("list-student")):[];
    liststudent.push({
        mssv:item_mssv,
        namestudent:item_namestudent,
        gender:item_gender,
        birthday:item_birthday,
        classstudent:item_classstudent,
        khoastudent:item_khoastudent
    })
    localStorage.setItem("list-student",JSON.stringify( liststudent))
    readerstudent();
    clearstudent();
}
function readerstudent(){
    let liststudent=localStorage.getItem("list-student") ? JSON.parse(localStorage.getItem("list-student")):[];
    let table=`
        <tr class="phongchu3 phongchu9">
                        <td>STT</td>
                        <td>Mã Sinh Viên</td>
                        <td>Họ Tên</td>
                         <td>Giới Tính</td>
                        <td>Ngày Sinh</td>
                        <td>Lớp </td>
                        <td>Khoa</td>
                        <td>Thao Tác</td>
                    </tr>`      
    liststudent.map((value,index)=>{
                table+=`
                <tr class=" phongchu9">
                        <td>${index+1}</td>
                        <td>${value.mssv}</td>
                        <td>${ value.namestudent}</td>
                        <td>${value.gender}</td>
                        <td>${value.birthday}</td>
                        <td>${ value.classstudent}</td>
                        <td>${ value.khoastudent}</td>
                        <td><button onclick="deletestudent(${index})" >
                        <i class="fa-solid fa-box"></i></button>
                        <button onclick="editstudent(${index})" >
                        <i class="fa-solid fa-pen-to-square"></i></td>
                    </tr>
                `
        })
        document.getElementById("table5").innerHTML=table
    
}

     function deletestudent(index){
        let liststudent=localStorage.getItem("list-student") ? JSON.parse(localStorage.getItem("list-student")):[];
        if(confirm("Bạn muốn xóa chứ"))
        {
            liststudent.splice(index,1)
    
        } 
        localStorage.setItem("list-student",JSON.stringify( liststudent))
        readerstudent()
    }
    function editstudent(index){
        let liststudent=localStorage.getItem("list-student") ? JSON.parse(localStorage.getItem("list-student")):[];
                document.getElementById("mssv").value=liststudent[index].mssv; 
                document.getElementById("namestudent").value=liststudent[index].namestudent; 
                document.getElementById("gender").value=liststudent[index].gender; 
                document.getElementById("birthday").value=liststudent[index].birthday; 
                document.getElementById("classstudent").value=liststudent[index].classstudent; 
                document.getElementById("khoastudent").value=liststudent[index].khoastudent;     
                document.getElementById("indexstudent").value=index
                document.getElementById("add4").style.display="none"
                document.getElementById("save4").style.display="inline-block"
            }
    function changestudent(){
        let liststudent=localStorage.getItem("list-student") ? JSON.parse(localStorage.getItem("list-student")):[];
                 let index=document.getElementById("indexstudent").value
                 liststudent[index]={
                    mssv: document.getElementById("mssv").value,
                     namestudent: document.getElementById("namestudent").value,
                     gender:document.getElementById("gender").value,
                     birthday:document.getElementById("birthday").value,
                     classstudent:document.getElementById("classstudent").value,
                 khoastudent:document.getElementById("khoastudent").value
                 }
                 localStorage.setItem("list-student",JSON.stringify(liststudent))
                 readerstudent()
                 document.getElementById("add4").style.display="inline-block"
                 document.getElementById("save4").style.display="none"
                clearstudent();
             }
             function searchstudent(){
                let liststudent=localStorage.getItem("list-student") ? JSON.parse(localStorage.getItem("list-student")):[];
            let valuesearch=document.getElementById("searchstudent").value
            let valuesearch1=document.getElementById("searchsinhvien").value
            let studentsearch=liststudent.filter(value=>{
                return value.mssv.toUpperCase().includes(valuesearch.toUpperCase())
            })
            let studentsearch1=studentsearch.filter(value=>{
                return value.namestudent.toUpperCase().includes(valuesearch1.toUpperCase())
            })
            readerstudent(studentsearch)
            readerstudent1(studentsearch1)
            document.getElementById("searchstudent").value=""
            document.getElementById("searchsinhvien").value=""
            }
            function ascendingstudent(){
                let liststudent=localStorage.getItem("list-student") ? JSON.parse(localStorage.getItem("list-student")):[];
                let valueSelect=document.getElementById("sortstudent").value
                liststudent.sort((a , b)=>{
                    if(valueSelect==="az"){
                        return a.namestudent.localeCompare(b.namestudent)
                    }else if(valueSelect==="za"){
                        return b.namestudent.localeCompare(a.namestudent)
                    } else if(valueSelect==="az1"){
                        return a.mssv.localeCompare(b.mssv)
                    }else if(valueSelect==="za1"){
                        return b.mssv.localeCompare(a.mssv)
                    } return a.namestudent-b.namestudent
                })
                readerstudent1(liststudent)
            }


            function readerstudent1(studentsearch){
                let table=`
                    <tr class="phongchu3 phongchu9">
                                    <td>STT</td>
                                    <td>Mã Sinh Viên</td>
                                    <td>Họ Tên</td>
                                     <td>Giới Tính</td>
                                    <td>Ngày Sinh</td>
                                    <td>Lớp </td>
                                    <td>Khoa</td>
                                    <td>Thao Tác</td>
                                </tr>`      
                studentsearch.map((value,index)=>{
                            table+=`
                            <tr class=" phongchu9">
                                    <td>${index+1}</td>
                                    <td>${value.mssv}</td>
                                    <td>${ value.namestudent}</td>
                                    <td>${value.gender}</td>
                                    <td>${value.birthday}</td>
                                    <td>${ value.classstudent}</td>
                                    <td>${ value.khoastudent}</td>
                                    <td><button onclick="deletestudent(${index})" >
                                    <i class="fa-solid fa-box"></i></button>
                                    <button onclick="editstudent(${index})" >
                                    <i class="fa-solid fa-pen-to-square"></i></td>
                                </tr>
                            `
                    })
                    document.getElementById("table5").innerHTML=table
                
            }
             function cleardiem(){ 
                document.getElementById("masosinhvien").value=""; 
                document.getElementById("tensinhvien").value=""; 
                document.getElementById("mamonhoc").value=""; 
                document.getElementById("tenmonhoc").value=""; 
                document.getElementById("diem").value=""; 
                    }
                function adddiem(){
                   let diem=[]
                  let item_masosinhvien= document.getElementById("masosinhvien").value; 
                  let item_tensinhvien=document.getElementById("tensinhvien").value; 
                  let item_mamonhoc=document.getElementById("mamonhoc").value; 
                  let item_tenmonhoc=document.getElementById("tenmonhoc").value; 
                  let item_diem=document.getElementById("diem").value;
                   let listdiem=localStorage.getItem("list-diem") ? JSON.parse(localStorage.getItem("list-diem")):[];
                   listdiem.push({
                    masosinhvien:item_masosinhvien,
                    tensinhvien:item_tensinhvien,
                    mamonhoc: item_mamonhoc,
                    tenmonhoc: item_tenmonhoc,
                    diem:item_diem
                   })
                   localStorage.setItem("list-diem",JSON.stringify( listdiem))
                   readerdiem();
                   cleardiem();
               }
               function readerdiem(){
                   let listdiem=localStorage.getItem("list-diem") ? JSON.parse(localStorage.getItem("list-diem")):[];
                      let table4=`
                       <tr class="phongchu3 phongchu9">
                       <td>ID</td>
                       <td>Mã Sinh Viên</td>
                        <td>Họ Tên </td>
                        <td>Mã Môn Học </td>
                       <td>Tên Môn Học </td>
                         <td>Điểm</td>
                         <td>Thao Tác</td>
                   </tr>`      
                   listdiem.map((value,index)=>{
                               table4 +=`
                               <tr class=" phongchu9">
                                       <td>${index+1}</td>
                                       <td>${value. masosinhvien}</td>
                                       <td>${ value.tensinhvien}</td>
                                       <td>${value.mamonhoc}</td>
                                       <td>${ value.tenmonhoc}</td>
                                       <td>${value.diem}</td>
                                       <td><button onclick="deletediem(${index})" >
                                       <i class="fa-solid fa-box"></i></button>
                                       <button onclick="editdiem(${index})" >
                                       <i class="fa-solid fa-pen-to-square"></i></td>
               
                                   </tr>
                               `
                       })
                       document.getElementById("table6").innerHTML=table4}
                    function deletediem(index){
                       let listdiem=localStorage.getItem("list-diem") ? JSON.parse(localStorage.getItem("list-diem")):[];
                       if(confirm("Bạn muốn xóa chứ"))
                       {
                           listdiem.splice(index,1)
                   
                       } 
                       localStorage.setItem("list-diem",JSON.stringify( listdiem))
                       readerdiem()
                   }
 function editdiem(index){
                       let listdiem=localStorage.getItem("list-diem") ? JSON.parse(localStorage.getItem("list-diem")):[];
                       document.getElementById("masosinhvien").value= listdiem[index].masosinhvien; 
                       document.getElementById("tensinhvien").value=listdiem[index].tensinhvien;
                        document.getElementById("mamonhoc").value= listdiem[index].mamonhoc; 
                        document.getElementById("tenmonhoc").value=listdiem[index].tenmonhoc; 
                        document.getElementById("diem").value= listdiem[index].diem; 
                               document.getElementById("indexdiem").value=index
                               document.getElementById("add6").style.display="none"
                               document.getElementById("save6").style.display="inline-block"
                           }
 function changediem(){
                       let listdiem=localStorage.getItem("list-diem") ? JSON.parse(localStorage.getItem("list-diem")):[];
                                let index=document.getElementById("indexdiem").value
                                listdiem[index]={
                                    masosinhvien: document.getElementById("masosinhvien").value,
                                    tensinhvien: document.getElementById("tensinhvien").value,
                                    mamonhoc: document.getElementById("mamonhoc").value,
                                    tenmonhoc: document.getElementById("tenmonhoc").value,
                                   diem: document.getElementById("diem").value
                                }
                                localStorage.setItem("list-diem",JSON.stringify(listdiem))
                                readerdiem()
                                document.getElementById("add6").style.display="inline-block"
                                document.getElementById("save6").style.display="none"
                               cleardiem();
                            }
function searchdiem(){
                            let listdiem=localStorage.getItem("list-diem") ? JSON.parse(localStorage.getItem("list-diem")):[];
                            let valuesearch=document.getElementById("searchmssv").value
                            let valuesearch1=document.getElementById("searchname").value
                            let valuesearch2=document.getElementById("searchcodemon").value
                            let valuesearch3=document.getElementById("searchnamehoc").value
                            let diemsearch=listdiem.filter(value=>{
                                return value.masosinhvien.toUpperCase().includes(valuesearch.toUpperCase())
                            })
                            let diemsearch1=diemsearch.filter(value=>{
                                return value.tensinhvien.toUpperCase().includes(valuesearch1.toUpperCase())
                            })
                            let diemsearch2=diemsearch1.filter(value=>{
                                return value.mamonhoc.toUpperCase().includes(valuesearch2.toUpperCase())
                            })
                            let diemsearch3=diemsearch2.filter(value=>{
                                return value.tenmonhoc.toUpperCase().includes(valuesearch3.toUpperCase())
                            })
                            readerdiem1(diemsearch)
                            readerdiem1(diemsearch1)
                            readerdiem1(diemsearch2)
                            readerdiem1(diemsearch3)
                            document.getElementById("searchmssv").value=""
                            document.getElementById("searchname").value=""
                            document.getElementById("searchnamehoc").value=""
                            document.getElementById("searchcodemon").value=""
                            }

                            function ascendingdiem(){
                                let listdiem=localStorage.getItem("list-diem") ? JSON.parse(localStorage.getItem("list-diem")):[];
                                let valueSelect=document.getElementById("sortdiem").value
                                listdiem.sort((a , b)=>{
                                    if(valueSelect==="az"){
                                        return a.masosinhvien.localeCompare(b.masosinhvien)
                                    }else if(valueSelect==="za"){
                                        return b.masosinhvien.localeCompare(a.masosinhvien)
                                    } else if(valueSelect==="az1"){
                                        return a.tensinhvien.localeCompare(b.tensinhvien)
                                    }else if(valueSelect==="za1"){
                                        return b.tensinhvien.localeCompare(a.tensinhvien)
                                    }else if(valueSelect==="az2"){
                                        return a.diem.localeCompare(b.diem)
                                    } else if(valueSelect==="za2"){
                                        return b.diem.localeCompare(a.diem)
                                    }
                                    return a.searchmssv-b.searchmssv
                                })
                                readerdiem1(listdiem)
                            }
     function readerdiem1(diemsearch){
                                   let table4=`
                                   <tr class="phongchu3 phongchu9">
                       <td>ID</td>
                       <td>Mã Sinh Viên</td>
                        <td>Họ Tên </td>
                        <td>Mã Môn Học </td>
                       <td>Tên Môn Học </td>
                         <td>Điểm</td>
                         <td>Thao Tác</td>
                   </tr>`      
                                diemsearch.map((value,index)=>{
                                            table4 +=`
                                            <tr class=" phongchu9">
                                                    <td>${index+1}</td>
                                                    <td>${value. masosinhvien}</td>
                                                    <td>${ value.tensinhvien}</td>
                                                    <td>${value.mamonhoc}</td>
                                                    <td>${ value.tenmonhoc}</td>
                                                    <td>${value.diem}</td>
                                                    <td><button onclick="deletediem(${index})" >
                                                    <i class="fa-solid fa-box"></i></button>
                                                    <button onclick="editdiem(${index})" >
                                                    <i class="fa-solid fa-pen-to-square"></i></td>
                            
                                                </tr>
                                            `
                                    })
                                    document.getElementById("table6").innerHTML=table4
                            }
                            function clearphancong(){ 
                                document.getElementById("nameteacher").value=""; 
                                document.getElementById("mongiangday").value=""; 
                                document.getElementById("lopday").value=""; 
                                document.getElementById("hocky").value=""; 
                                document.getElementById("nam").value=""; 
                                    }
                                function addphancong(){
                                   let phancong=[]
                                  let item_nameteacher= document.getElementById("nameteacher").value; 
                                  let item_mongiangday=document.getElementById("mongiangday").value; 
                                  let item_lopday=document.getElementById("lopday").value; 
                                  let item_hocky=document.getElementById("hocky").value; 
                                  let item_nam=document.getElementById("nam").value;
                                   let listphancong=localStorage.getItem("list-phancong") ? JSON.parse(localStorage.getItem("list-phancong")):[];
                                   listphancong.push({
                                       nameteacher:item_nameteacher,
                                       mongiangday:item_mongiangday,
                                       lopday: item_lopday,
                                       hocky: item_hocky,
                                       nam:item_nam
                                   })
                                   localStorage.setItem("list-phancong",JSON.stringify( listphancong))
                                   readerphancong();
                                   clearphancong();
                               }
                               function readerphancong(){
                                   let listphancong=localStorage.getItem("list-phancong") ? JSON.parse(localStorage.getItem("list-phancong")):[];
                                      let table4=`
                                       <tr class="phongchu3 phongchu9 ">
                                       <td>ID</td>
                                       <td>Tên Giảng Viên</td>
                                        <td>Môn Học Giảng Dạy </td>
                                        <td>Lớp Học </td>
                                       <td>Học Kỳ </td>
                                         <td>Năm</td>
                                         <td>Thao Tác</td>
                                   </tr>`      
                                   listphancong.map((value,index)=>{
                                             table4 +=`
                                               <tr class=" phongchu9">
                                                       <td>${index+1}</td>
                                                       <td>${value.nameteacher}</td>
                                                       <td>${ value.mongiangday}</td>
                                                       <td>${value.lopday}</td>
                                                       <td>${ value.hocky}</td>
                                                       <td>${value.nam}</td>
                                                       <td><button onclick="deletephancong(${index})" >
                                                       <i class="fa-solid fa-box"></i></button>
                                                       <button onclick="editphancong(${index})" >
                                                       <i class="fa-solid fa-pen-to-square"></i></td>
                               
                                                   </tr>`}) 
                                                   document.getElementById("table7").innerHTML=table4
                                    }
                                    function deletephancong(index){
                                       let listphancong=localStorage.getItem("list-phancong") ? JSON.parse(localStorage.getItem("list-phancong")):[];
                                       if(confirm("Bạn muốn xóa chứ"))
                                       {
                                           listphancong.splice(index,1)
                                   
                                       } 
                                       localStorage.setItem("list-phancong",JSON.stringify( listphancong))
                                       readerphancong()
                                   }
                                   function editphancong(index){
                                       let listphancong=localStorage.getItem("list-phancong") ? JSON.parse(localStorage.getItem("list-phancong")):[];
                                               document.getElementById("nameteacher").value= listphancong[index].nameteacher; 
                                               document.getElementById("mongiangday").value=listphancong[index].mongiangday;
                                               document.getElementById("lopday").value= listphancong[index].lopday; 
                                               document.getElementById("hocky").value=listphancong[index].hocky; 
                                               document.getElementById("nam").value= listphancong[index].nam; 
                                               document.getElementById("indexphancong").value=index
                                               document.getElementById("add7").style.display="none"
                                               document.getElementById("save7").style.display="inline-block"
                                           }
                                   function changephancong(){
                                       let listphancong=localStorage.getItem("list-phancong") ? JSON.parse(localStorage.getItem("list-phancong")):[];
                                                let index=document.getElementById("indexphancong").value
                                                listphancong[index]={
                                                   nameteacher: document.getElementById("nameteacher").value,
                                                   mongiangday: document.getElementById("mongiangday").value,
                                                   lopday: document.getElementById("lopday").value,
                                                   hocky: document.getElementById("hocky").value,
                                                   nam: document.getElementById("nam").value
                                                }
                                                localStorage.setItem("list-phancong",JSON.stringify(listphancong))
                                                readerphancong()
                                                document.getElementById("add7").style.display="inline-block"
                                                document.getElementById("save7").style.display="none"
                                               clearphancong();
                                            }
    function searchphancong(){
                                                let listphancong=localStorage.getItem("list-phancong") ? JSON.parse(localStorage.getItem("list-phancong")):[];
                                            let valuesearch=document.getElementById("searchphancong").value
                                            let phancongsearch=listphancong.filter(value=>{
                                                return value.nameteacher.toUpperCase().includes(valuesearch.toUpperCase())
                                            })
                                            readerphancong1(phancongsearch)
                                            document.getElementById("searchphancong").value=""
                                            }
 function readerphancong1(phancongsearch){
                                                   let table4=`
                                                    <tr class="phongchu3 phongchu9 ">
                                                    <td>ID</td>
                                                    <td>Tên Giảng Viên</td>
                                                     <td>Môn Học Giảng Dạy </td>
                                                     <td>Lớp Học </td>
                                                    <td>Học Kỳ </td>
                                                      <td>Năm</td>
                                                      <td>Thao Tác</td>
                                                </tr>`      
                                                phancongsearch.map((value,index)=>{
                                                          table4 +=`
                                                            <tr class=" phongchu9">
                                                                    <td>${index+1}</td>
                                                                    <td>${value.nameteacher}</td>
                                                                    <td>${ value.mongiangday}</td>
                                                                    <td>${value.lopday}</td>
                                                                    <td>${ value.hocky}</td>
                                                                    <td>${value.nam}</td>
                                                                    <td><button onclick="deletephancong(${index})" >
                                                                    <i class="fa-solid fa-box"></i></button>
                                                                    <button onclick="editphancong(${index})" >
                                                                    <i class="fa-solid fa-pen-to-square"></i></td>
                                            
                                                                </tr>
                                                            `
                                                    })
                                                    document.getElementById("table7").innerHTML=table4
                                                
                                            }
function init(){
    document.getElementById("chart").style.display='block';
    document.getElementById("infoteacher").style.display='none';
    document.getElementById("infokhoa").style.display='none';
    document.getElementById("infomon").style.display='none';
    document.getElementById("infolop").style.display='none';
    document.getElementById("infostudent").style.display='none';
    document.getElementById("infodiem").style.display='none';
    document.getElementById("infophan").style.display='none';

    document.getElementById("trangchu").onclick=function(){
    document.getElementById("chart").style.display='block';
    document.getElementById("infoteacher").style.display='none';
    document.getElementById("infokhoa").style.display='none';
    document.getElementById("infomon").style.display='none';
    document.getElementById("infolop").style.display='none';
    document.getElementById("infostudent").style.display='none';
    document.getElementById("infodiem").style.display='none';
    document.getElementById("infophan").style.display='none';}

    document.getElementById("GV").onclick=function(){
    document.getElementById("infoteacher").style.display='block';
    document.getElementById("infokhoa").style.display='none';
    document.getElementById("infomon").style.display='none';
    document.getElementById("infolop").style.display='none';
    document.getElementById("infostudent").style.display='none';
    document.getElementById("infodiem").style.display='none';
    document.getElementById("infophan").style.display='none';
    document.getElementById("chart").style.display='none';
    }
    document.getElementById("DSK").onclick=function(){
        document.getElementById("infokhoa").style.display='block';
        document.getElementById("infoteacher").style.display='none';
        document.getElementById("infomon").style.display='none';
        document.getElementById("infolop").style.display='none';
        document.getElementById("infostudent").style.display='none';
        document.getElementById("infodiem").style.display='none';
        document.getElementById("infophan").style.display='none';
        document.getElementById("chart").style.display='none';
        }
    document.getElementById("DSL").onclick=function(){
            document.getElementById("infokhoa").style.display='none';
            document.getElementById("infoteacher").style.display='none';
            document.getElementById("infomon").style.display='none';
            document.getElementById("infolop").style.display='block';
            document.getElementById("infostudent").style.display='none';
            document.getElementById("infodiem").style.display='none';
            document.getElementById("infophan").style.display='none';
            document.getElementById("chart").style.display='none';
            }
    document.getElementById("HS").onclick=function(){
                document.getElementById("infokhoa").style.display='none';
                document.getElementById("infoteacher").style.display='none';
                document.getElementById("infomon").style.display='none';
                document.getElementById("infolop").style.display='none';
                document.getElementById("infostudent").style.display='block';
                document.getElementById("infodiem").style.display='none';
                document.getElementById("infophan").style.display='none';
                document.getElementById("chart").style.display='none';
                }
     document.getElementById("DSM").onclick=function(){
                    document.getElementById("infokhoa").style.display='none';
                    document.getElementById("infoteacher").style.display='none';
                    document.getElementById("infomon").style.display='block';
                    document.getElementById("infolop").style.display='none';
                    document.getElementById("infostudent").style.display='none';
                    document.getElementById("infodiem").style.display='none';
                    document.getElementById("infophan").style.display='none';
                    document.getElementById("chart").style.display='none';
                    }
    document.getElementById("PCGV").onclick=function(){
                        document.getElementById("infokhoa").style.display='none';
                        document.getElementById("infoteacher").style.display='none';
                        document.getElementById("infomon").style.display='none';
                        document.getElementById("infolop").style.display='none';
                        document.getElementById("infostudent").style.display='none';
                        document.getElementById("infodiem").style.display='none';
                        document.getElementById("infophan").style.display='block';
                        document.getElementById("chart").style.display='none';
                        }
 document.getElementById("DSD").onclick=function(){
                            document.getElementById("infokhoa").style.display='none';
                            document.getElementById("infoteacher").style.display='none';
                            document.getElementById("infomon").style.display='none';
                            document.getElementById("infolop").style.display='none';
                            document.getElementById("infostudent").style.display='none';
                            document.getElementById("infodiem").style.display='block';
                            document.getElementById("infophan").style.display='none';
                            document.getElementById("chart").style.display='none';
                            }                   
}
function data(){
    readerteacher();
    readerkhoa();
    readerclass();
    readermon();
    readerstudent();
    readerdiem();
    readerphancong();
var xValues = ["Khoa CNTT", "Khoa TCNC", "Khoa CNSH", "Khoa XD", "Khoa ĐTĐB","Khoa NN"];
var yValues = [30, 35, 28,29, 40,42];
var barColors = [
  "#b91d47",
  "#00aba9",
  "#2b5797",
  "#e8c3b9",
  "#1e7145",
  "#1e145a"
];

new Chart("myChart1", {
  type: "doughnut",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Tổng Số Giảng Viên Của Trường"
    }
  }
});
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);
function drawChart() {
var data = google.visualization.arrayToDataTable([
  ['sinh vien', 'Mhl'],
  ['Khoa CNTT',1500],
  ['Khoa TCNC',1400],
  ['Khoa CNSH',1000],
  ['Khoa ĐTĐB',800],
  ['Khoa XD',1200],
  ['Khoa NN',1600]
]);
var options = {
  title:' Số Sinh Viên Của Trường ',
  is3D:true
};
var chart = new google.visualization.PieChart(document.getElementById('myChart'));
  chart.draw(data, options);
}
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart2);

function drawChart2() {
var data = google.visualization.arrayToDataTable([
  ['Năm Học', 'Đạt'],
  ['HKI Năm 2020-2021',8000],
  ['HKII Năm 2020-2021',7000],
  ['HKIII Năm 2020-2021',10000],
  ['HKI Năm 2021-2022',8500],
  ['HKII Năm 2021-2022',9000]
]);
var options = {
  title:'Thí Sinh Đạt Hay Rớt Môn'
};

var chart = new google.visualization.BarChart(document.getElementById('myChart2'));
  chart.draw(data, options);
}

var xValues = [1,2,3,4,5,6,7,8,9,10];

new Chart("myChart3", {
    optionss : {
        title:'World Wide Wine Production'
      },
  type: "line",
  data: {
    labels: xValues,
    datasets: [{ 
      data: [150,220,260,900,1500,4000,580,850,86,95],
      borderColor: "red",
      fill: false
    }, { 
      data: [150,100,260,3000,1560,899,1500,850,100,50],
      borderColor: "green",
      fill: false
    }, { 
      data: [100,20,660,500,4500,900,670,50,86,95],
      borderColor: "blue",
      fill: false
    }]
    
  },
  options: {
    legend: {display: false}
  }
  
});

}